﻿using MvcApplication29.Models;
using MvcApplication29.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication29.Controllers
{
    public class ServiceController : Controller
    {
         private  IRepository<Book,int> interfaceObj;

         public ServiceController()
        {

            this.interfaceObj = new RepositoryService<Book,int>();
        }
        public JsonResult GetAllBooks()
         {
             var v = interfaceObj.GetAll();
             return Json(v, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetBookById(int id)
        {
            var v = interfaceObj.Get(id);
            return Json(v, JsonRequestBehavior.AllowGet);
        }
        public void  AddBook(Book book)
        {
             interfaceObj.Add(book);
        }
        
    }
}
