﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MvcApplication29.Models.Repository
{
    public class RepositoryService<TEntity, TKey> : IRepository<TEntity, TKey> where TEntity : class
    {
        protected readonly DbContext Context;

        protected DbSet<TEntity> DbSet;

        public RepositoryService()
        {
            Context = new TestDBEntities();
            DbSet = Context.Set<TEntity>();
        }

        public void Add(TEntity entity)
        {
            Context.Set<TEntity>().Add(entity);

            Save();
        }

        public TEntity Get<TKey>(TKey id)
        {
            return DbSet.Find(id);
        }

        public IQueryable<TEntity> GetAll()
        {
            return DbSet;
        }

        public void Update(TEntity entity)
        {
            Context.Entry(entity).State = System.Data.EntityState.Modified;
            Save();
        }

        private void Save()
        {
            Context.SaveChanges();
        }
    }
}