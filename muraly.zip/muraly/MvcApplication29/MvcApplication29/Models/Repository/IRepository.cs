﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvcApplication29.Models.Repository
{
    public interface IRepository<TEntity,TKey>
    {
        TEntity Get<TKey>(TKey id);
        IQueryable<TEntity> GetAll();
        void Add(TEntity entity);
        void Update(TEntity entity);
    }
}
